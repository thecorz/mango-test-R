library(testthat)
library(drawsample)

test_check("drawsample")
